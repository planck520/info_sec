#!/bin/sh
#AN1202L
echo "" > /tmp/deviceMac.txt && get_dev_mac > /tmp/deviceMac.txt && echo "" >> /tmp/deviceMac.txt
